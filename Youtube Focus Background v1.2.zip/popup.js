const bgInput = document.getElementById('bgInput');
const saveBgBtn = document.getElementById('saveBgBtn');
const statusMsg = document.getElementById('status');
const historyList = document.getElementById('historyList');
const historySection = document.getElementById('historySection');
const blurToggle = document.getElementById('blurToggle');
const blurSlider = document.getElementById('blurSlider');
const blurValText = document.getElementById('blurVal');
const blurControl = document.getElementById('blurControl');
const modeToggle = document.getElementById('modeToggle');


browser.storage.local.get({ 
    bgUrl: '', 
    bgHistory: [], 
    blurEnabled: true, 
    blurAmount: 15,
    popupDarkMode: false 
}).then(data => {
    if (data.bgUrl) bgInput.value = data.bgUrl;
    blurToggle.checked = data.blurEnabled;
    blurSlider.value = data.blurAmount;
    blurValText.textContent = data.blurAmount + "px";
    blurControl.style.display = data.blurEnabled ? 'block' : 'none';
    
    if (data.popupDarkMode) {
        document.body.classList.add('dark-mode');
        modeToggle.textContent = "Light";
    }
    
    renderHistory(data.bgHistory);
});

modeToggle.onclick = () => {
    const isDark = document.body.classList.toggle('dark-mode');
    modeToggle.textContent = isDark ? "Light" : "Dark";
    browser.storage.local.set({ popupDarkMode: isDark });
};

blurSlider.oninput = function() { blurValText.textContent = this.value + "px"; };
blurToggle.onchange = function() { blurControl.style.display = this.checked ? 'block' : 'none'; };

function renderHistory(history) {
    historyList.innerHTML = '';
    if (history && history.length > 0) {
        historySection.style.display = 'block';
        history.forEach(url => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.style.backgroundImage = `url('${url}')`;
            item.onclick = () => { bgInput.value = url; saveSettings(); };
            historyList.appendChild(item);
        });
    }
}

async function saveSettings() {
    const url = bgInput.value.trim();
    const isBlur = blurToggle.checked;
    const blurPx = blurSlider.value;

    const data = await browser.storage.local.get({ bgHistory: [] });
    let newHistory = data.bgHistory;
    
    if (url && !newHistory.includes(url)) {
        newHistory.unshift(url);
        newHistory = newHistory.slice(0, 10);
    }

    await browser.storage.local.set({ 
        bgUrl: url, 
        bgHistory: newHistory,
        blurEnabled: isBlur,
        blurAmount: blurPx
    });

    statusMsg.textContent = "Applying design...";
    renderHistory(newHistory);
    
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].url.includes("youtube.com")) {
        browser.tabs.reload(tabs[0].id);
    }
    
    setTimeout(() => { statusMsg.textContent = "Style updated!"; }, 800);
}

saveBgBtn.addEventListener('click', saveSettings);