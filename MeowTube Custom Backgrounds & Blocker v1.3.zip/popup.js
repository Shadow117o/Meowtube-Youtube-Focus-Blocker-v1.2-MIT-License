
const bgInput = document.getElementById('bgInput');
const saveBgBtn = document.getElementById('saveBgBtn');
const statusMsg = document.getElementById('status');
const historyList = document.getElementById('historyList');
const historySection = document.getElementById('historySection');
const blurToggle = document.getElementById('blurToggle');
const blurSlider = document.getElementById('blurSlider');
const blurValText = document.getElementById('blurVal');
const blurControl = document.getElementById('blurControl');
const modeToggle = document.getElementById('modeToggle');
const kofiBtn = document.getElementById('kofiBtn');
const catContainer = document.getElementById('lottie-cat');
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');


const catAnimation = lottie.loadAnimation({
    container: catContainer,
    renderer: 'svg',
    loop: false,
    autoplay: false,
    path: 'cat before hovering.json'
});

let idleInterval;
function playIdle() { 
    if(catAnimation) catAnimation.playSegments([0, 22], true); 
}

catAnimation.addEventListener('DOMLoaded', () => {
    playIdle();
    idleInterval = setInterval(playIdle, 4500);
});

kofiBtn.onmouseenter = () => {
    clearInterval(idleInterval);
    catAnimation.playSegments([23, 110], true);
    catContainer.style.transform = 'scale(1.1) translateY(-5px)';
};

kofiBtn.onmouseleave = () => {
    catAnimation.playSegments([75, 23], true);
    const backToIdle = () => {
        catAnimation.removeEventListener('complete', backToIdle);
        playIdle();
        idleInterval = setInterval(playIdle, 4500);
    };
    catAnimation.addEventListener('complete', backToIdle);
    catContainer.style.transform = 'scale(1) translateY(0)';
};


function handleFile(file) {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
        statusMsg.textContent = "Error: File too large (max 8MB)";
        return;
    }
    const reader = new FileReader();
    statusMsg.textContent = "Reading file...";
    reader.onload = (event) => {
        bgInput.value = event.target.result;
        statusMsg.textContent = "Image loaded! Applying...";
        saveSettings(false); 
    };
    reader.readAsDataURL(file);
}

uploadBtn.onclick = () => {
    if (window.innerWidth < 400) {
        chrome.tabs.create({ url: 'popup.html?autoUpload=true' });
        window.close();
    } else {
        fileInput.click();
    }
};

fileInput.onchange = (e) => {
    if (e.target.files.length > 0) handleFile(e.target.files[0]);
};


async function saveSettings(isLiveUpdate = false) {
    const url = bgInput.value.trim();
    const updateData = {
        bgUrl: url,
        blurEnabled: blurToggle.checked,
        blurAmount: blurSlider.value
    };

    if (!isLiveUpdate && url) {
        const data = await chrome.storage.local.get({ bgHistory: [] });
        let newHistory = data.bgHistory.filter(item => item !== url);
        newHistory.unshift(url);
        updateData.bgHistory = newHistory.slice(0, 10);
        renderHistory(updateData.bgHistory);
    }

    await chrome.storage.local.set(updateData);
    const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/*" });
    tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, { action: "refreshStyle" }).catch(() => {
            if (!isLiveUpdate) chrome.tabs.reload(tab.id);
        });
    });

    if (!isLiveUpdate) {
        statusMsg.textContent = "Successfully updated!";
        setTimeout(() => statusMsg.textContent = "", 2000);
    }
}

function renderHistory(history) {
    historyList.innerHTML = '';
    if (history && history.length > 0) {
        historySection.style.display = 'block';
        history.forEach(url => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.style.backgroundImage = `url('${url}')`;
            item.onclick = () => { bgInput.value = url; saveSettings(false); };
            historyList.appendChild(item);
        });
    } else {
        historySection.style.display = 'none';
    }
}


chrome.storage.local.get({ 
    bgUrl: '', bgHistory: [], blurEnabled: true, blurAmount: 15, popupDarkMode: false 
}).then(data => {
    bgInput.value = data.bgUrl;
    blurToggle.checked = data.blurEnabled;
    blurSlider.value = data.blurAmount;
    blurValText.textContent = data.blurAmount + "px";
    blurControl.style.display = data.blurEnabled ? 'block' : 'none';
    if (data.popupDarkMode) {
        document.body.classList.add('dark-mode');
        document.body.style.setProperty('--invert-val', '1');
    }
    renderHistory(data.bgHistory);

    const params = new URLSearchParams(window.location.search);
    if (params.get('autoUpload') === 'true') {
        setTimeout(() => {
            fileInput.click();
            window.history.replaceState({}, '', 'popup.html');
        }, 400);
    }
});

modeToggle.onclick = () => {
    const isDark = document.body.classList.toggle('dark-mode');
    document.body.style.setProperty('--invert-val', isDark ? '1' : '0');
    chrome.storage.local.set({ popupDarkMode: isDark });
};
blurSlider.oninput = function() { blurValText.textContent = this.value + "px"; saveSettings(true); };
blurToggle.onchange = function() { blurControl.style.display = this.checked ? 'block' : 'none'; saveSettings(true); };
saveBgBtn.onclick = () => saveSettings(false);