const style = document.createElement('style'); 
style.id = "custom-yt-style"; 
style.textContent = ` 
    
    [ytr-home] #frosted-glass {
        display: none !important;
    }

    [ytr-home] #masthead-container.ytd-app,
    [ytr-home] #masthead-container.ytd-app::after,
    [ytr-home] ytd-masthead {
        box-shadow: none !important;
    }

   
    [ytr-home] #masthead-container,
    [ytr-home] ytd-guide-renderer, 
    [ytr-home] ytd-mini-guide-renderer, 
    [ytr-home] #guide-content.ytd-guide-renderer, 
    [ytr-home] #contentContainer.ytd-app ytd-guide-renderer { 
        background: var(--custom-blur-bg) !important; 
        backdrop-filter: var(--custom-blur-all) !important; 
        border-color: var(--custom-border-color) !important;
        transition: background 0.2s ease, backdrop-filter 0.2s ease !important;
    }

    [ytr-home] #masthead-container {
        border-bottom: 1px solid var(--custom-border-color) !important;
    }

    [ytr-home] ytd-guide-renderer {
        border-right: 1px solid var(--custom-border-color) !important;
    }

    
    [ytr-home] ytd-browse[page-subtype="home"] #primary, 
    [ytr-home] ytd-browse[page-subtype="home"] #contents, 
    [ytr-home] ytd-browse #grid-container, 
    [ytr-home] #chips-wrapper {  
        display: none !important;  
    } 

    [ytr-home] ytd-app { 
        background-image: var(--custom-bg-url) !important; 
        background-size: cover !important; 
        background-position: center center !important; 
        background-repeat: no-repeat !important; 
        background-attachment: fixed !important; 
        background-color: #000 !important; 
    } 

    [ytr-home] #content.ytd-app, 
    [ytr-home] ytd-page-manager,
    [ytr-home] #contentContainer.ytd-app, 
    [ytr-home] #guide-wrapper.ytd-guide-renderer { 
        background: transparent !important; 
    } 

    [ytr-home] ytd-masthead #center.ytd-masthead { 
        position: absolute !important; 
        top: 30vh !important; 
        left: 50% !important; 
        transform: translateX(-50%) !important; 
        width: 100% !important; 
        max-width: 600px !important; 
        margin: 0 !important; 
    } 

    
    [ytr-home] #guide-entry-text,  
    [ytr-home] .title.ytd-mini-guide-entry-renderer, 
    [ytr-home] yt-icon, 
    [ytr-home] #logo-icon, 
    [ytr-home] #country-code,
    [ytr-home] #text,
    [ytr-home] #label,
    [ytr-home] .caption { 
        color: var(--custom-text-color, #fff) !important; 
        fill: var(--custom-text-color, #fff) !important; 
        transition: color 0.3s ease !important;
    } 

   
    [ytr-home] input#search {
        color: var(--custom-text-color, #fff) !important;
    }

    [ytr-home] #guide-inner-content::-webkit-scrollbar { 
        display: none; 
    }
`; 
document.documentElement.appendChild(style);

async function applyBackground() {
    const data = await chrome.storage.local.get({ 
        bgUrl: '', 
        blurEnabled: true, 
        blurAmount: 15 
    });

    if (data.bgUrl) {
        document.documentElement.style.setProperty('--custom-bg-url', `url('${data.bgUrl}')`);
    }

    const isDarkMode = document.documentElement.hasAttribute('dark');
    const rootStyle = document.documentElement.style;

    if (data.blurEnabled) {
       
        if (isDarkMode) {
            rootStyle.setProperty('--custom-blur-bg', 'rgba(0, 0, 0, 0.3)'); 
            rootStyle.setProperty('--custom-text-color', '#ffffff'); 
        } else {
            rootStyle.setProperty('--custom-blur-bg', 'rgba(255, 255, 255, 0.3)'); 
            rootStyle.setProperty('--custom-text-color', '#000000'); 
        }
        
        rootStyle.setProperty('--custom-blur-all', `blur(${data.blurAmount}px) saturate(150%)`);
        rootStyle.setProperty('--custom-border-color', 'rgba(255, 255, 255, 0.1)');

    } else {
        
        rootStyle.setProperty('--custom-blur-all', 'none');
        const solidColor = isDarkMode ? '#0f0f0f' : '#ffffff';
        const textColor = isDarkMode ? '#ffffff' : '#000000';
        
        rootStyle.setProperty('--custom-blur-bg', solidColor);
        rootStyle.setProperty('--custom-text-color', textColor);
        rootStyle.setProperty('--custom-border-color', 'rgba(128, 128, 128, 0.2)');
    }
}

function updateHomeState() {
    const loc = window.location;
    const isHome = loc.pathname === "/" && (loc.search === "" || loc.search.startsWith("?"));

    if (isHome) {
        if (!document.documentElement.hasAttribute('ytr-home')) {
            document.documentElement.setAttribute('ytr-home', '');
        }
        applyBackground();
    } else {
        if (document.documentElement.hasAttribute('ytr-home')) {
            document.documentElement.removeAttribute('ytr-home');
        }
    }
}

setInterval(updateHomeState, 600);
window.addEventListener('yt-navigate-finish', updateHomeState);
window.addEventListener('popstate', updateHomeState);
updateHomeState();

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "refreshStyle") {
        applyBackground(); 
    }
});

